/*  Name: Om Choksi 
 *  Course: CNT 4714 Spring 2021
 *  Assignment title: Project 3 - Two-Tier Client-Server Application Development With MySQL and JDBC
 *  Date: March 31st, 2021
*/

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.exceptions.CommunicationsException;

import javax.swing.JButton;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JScrollPane;


public class GUI3 {

	private JFrame frmSqlClientApp;
	private JTextField textField_2;
	
	private String driver = "com.mysql.cj.jdbc.Driver";
	private String url = "jdbc:mysql://localhost:3306/project3";
	private String user;
	private String password;
	
	private Connection connection;
	private JPasswordField passwordField;
	private JTable table;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI3 window = new GUI3();
					window.frmSqlClientApp.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public GUI3() throws ClassNotFoundException, SQLException {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() throws SQLException, ClassNotFoundException{
		frmSqlClientApp = new JFrame();
		frmSqlClientApp.getContentPane().setFont(new Font("Times New Roman", Font.PLAIN, 17));
		frmSqlClientApp.getContentPane().setBackground(SystemColor.menu);
		frmSqlClientApp.setTitle("SQL Client App - (MJL - CNT 4714 - Spring 2021)");
		frmSqlClientApp.setBounds(100, 100, 846, 516);
		frmSqlClientApp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSqlClientApp.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Database Information");
		lblNewLabel.setBackground(Color.LIGHT_GRAY);
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblNewLabel.setBounds(10, 10, 252, 21);
		frmSqlClientApp.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("JDBC Driver");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(20, 41, 108, 21);
		frmSqlClientApp.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Database URL");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setForeground(Color.BLACK);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_1_1.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_1.setBounds(20, 72, 108, 21);
		frmSqlClientApp.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Username");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setOpaque(true);
		lblNewLabel_1_2.setForeground(Color.BLACK);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_1_2.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_2.setBounds(20, 103, 108, 21);
		frmSqlClientApp.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Password");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setOpaque(true);
		lblNewLabel_1_3.setForeground(Color.BLACK);
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_1_3.setBackground(Color.LIGHT_GRAY);
		lblNewLabel_1_3.setBounds(20, 134, 108, 21);
		frmSqlClientApp.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblEnter = new JLabel("Enter An SQL Command");
		lblEnter.setForeground(Color.BLUE);
		lblEnter.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblEnter.setBackground(Color.LIGHT_GRAY);
		lblEnter.setBounds(397, 10, 252, 21);
		frmSqlClientApp.getContentPane().add(lblEnter);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		textField_2.setColumns(10);
		textField_2.setBounds(145, 106, 222, 21);
		frmSqlClientApp.getContentPane().add(textField_2);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("No Connection Now");
		lblNewLabel_1_1_1.setOpaque(true);
		lblNewLabel_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_1.setForeground(Color.RED);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		lblNewLabel_1_1_1.setBackground(Color.BLACK);
		lblNewLabel_1_1_1.setBounds(10, 217, 283, 27);
		frmSqlClientApp.getContentPane().add(lblNewLabel_1_1_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(145, 136, 222, 21);
		frmSqlClientApp.getContentPane().add(passwordField);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(397, 40, 408, 167);
		frmSqlClientApp.getContentPane().add(scrollPane_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		scrollPane_1.setViewportView(textArea);
		
		JButton btnNewButton = new JButton("Connect to Database");
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				//Checking if there already is a connection
				if (connection != null) {
					try {
						if (!connection.isClosed()) {
							connection.close();
						}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				
				while (textField_2.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please enter client or root user", "Message", JOptionPane.INFORMATION_MESSAGE);
					textField_2.setText("");
					lblNewLabel_1_1_1.setText("No Connection Now");
					return;
				}
				while (passwordField.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "Please enter a password", "Message", JOptionPane.INFORMATION_MESSAGE);
					passwordField.setText("");
					lblNewLabel_1_1_1.setText("No Connection Now");
					return;
				}
				
				//Driver Connection
				try { 
					Class.forName(driver);
				} catch (ClassNotFoundException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
					lblNewLabel_1_1_1.setText("No Connection Now");
					e1.printStackTrace();
					return;
				}
				
				//URL Connection 
				if (!connect(passwordField.getText(), textField_2.getText(), url)) {	
					textField_2.setText("");
					passwordField.setText("");
					lblNewLabel_1_1_1.setText("No Connection Now");
					return;
				}
				
				/* try {
					connection = DriverManager.getConnection(url, textField_2.getText(), passwordField.getText());
				} catch (ClassNotFoundException e2) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (CommunicationsException error) {
					// TODO Auto-generated catch block
					error.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "Wrong username or password", "Message", JOptionPane.INFORMATION_MESSAGE);
					e1.printStackTrace();
				}
				*/ 
				
				lblNewLabel_1_1_1.setText("Connected to " + url);
			}
		});
		
		btnNewButton.setOpaque(true);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setBackground(Color.BLUE);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnNewButton.setForeground(Color.YELLOW);
		btnNewButton.setBounds(303, 217, 169, 27);
		frmSqlClientApp.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear SQL Command");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("");
			}
		});
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setOpaque(true);
		btnNewButton_1.setBorderPainted(false);
		btnNewButton_1.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(482, 217, 167, 27);
		frmSqlClientApp.getContentPane().add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(41, 273, 764, 154);
		frmSqlClientApp.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		scrollPane.setViewportView(table);
		
		JButton btnNewButton_2 = new JButton("Execute SQL Command");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Statement statement = null;
				
				//Non-Select Queries
				if (!textArea.getText().startsWith("select")) {
					try {
						statement = connection.createStatement();
						statement.executeUpdate(textArea.getText());
						JOptionPane.showMessageDialog(null, "Command Executed", "Message", JOptionPane.INFORMATION_MESSAGE);
						statement.close();
						return;
					} catch (SQLSyntaxErrorException e1) {
						JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
						e1.printStackTrace();
						return;
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
						e1.printStackTrace();
						return;
					}
				}
				
				//Select Queries
				try {
					statement = connection.createStatement();
					//Execute Statement and query
					ResultSet result = statement.executeQuery(textArea.getText());
					ResultSetMetaData metaData = result.getMetaData();
					int columns = metaData.getColumnCount();
					
					//Creating Table Model object
					DefaultTableModel tableModel = new DefaultTableModel();
					Object[] row = new Object[columns];
 					
					for (int i = 1; i <= columns; i++) {
						//System.out.printf("%-20s\t", metaData.getColumnName(i));
						tableModel.addColumn(metaData.getColumnName(i));
					}
					
					/* for (int i = 1; i <= columns; i++) {
						System.out.printf("%-20s\t", "-----------------------");
					} */
					
					while (result.next()) {
						for (int i = 0; i < columns; i++) {
							//System.out.printf("%-20s\t", result.getObject(i+1));
							row[i] = result.getObject(i+1);
						}
						//System.out.println();
						tableModel.addRow(row);
					}
					//System.out.println();
					table.setModel(tableModel);
					//close statement
					statement.close();
					
					//Error Handling .replaceAll("java.sql.SQLSyntaxErrorException: ", "")
				} catch (SQLSyntaxErrorException e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
					e1.printStackTrace();
					return;
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Error", JOptionPane.INFORMATION_MESSAGE);
					e1.printStackTrace();
					return;
				} 
			}			
		});
		btnNewButton_2.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_2.setBackground(Color.GREEN);
		btnNewButton_2.setOpaque(true);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setFont(new Font("Times New Roman", Font.BOLD, 13));
		btnNewButton_2.setBounds(658, 217, 164, 27);
		frmSqlClientApp.getContentPane().add(btnNewButton_2);
		
		JLabel lblSqlExecution = new JLabel("SQL Execution Result Window");
		lblSqlExecution.setForeground(Color.BLUE);
		lblSqlExecution.setFont(new Font("Times New Roman", Font.BOLD, 19));
		lblSqlExecution.setBackground(Color.LIGHT_GRAY);
		lblSqlExecution.setBounds(41, 254, 283, 21);
		frmSqlClientApp.getContentPane().add(lblSqlExecution);
		
		JButton btnClearResultWindow = new JButton("Clear Result Window");
		btnClearResultWindow.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				table.setModel(new DefaultTableModel());
			}
		});
		btnClearResultWindow.setOpaque(true);
		btnClearResultWindow.setForeground(Color.BLACK);
		btnClearResultWindow.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnClearResultWindow.setBorderPainted(false);
		btnClearResultWindow.setBackground(Color.YELLOW);
		btnClearResultWindow.setBounds(26, 437, 194, 27);
		frmSqlClientApp.getContentPane().add(btnClearResultWindow);
		
		String[] urls = {"jdbc:mysql://localhost:3306/project3"};
		JComboBox comboBox = new JComboBox(urls);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				url = urls[0];
			}
		});
		comboBox.setForeground(new Color(0, 0, 0));
		comboBox.setOpaque(true);
		comboBox.setBackground(Color.WHITE);
		comboBox.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		comboBox.setBounds(145, 72, 222, 27);
		frmSqlClientApp.getContentPane().add(comboBox);
		
		String[] drivers = {"com.mysql.cj.jdbc.Driver", "oracle.jdbc.driver.OracleDriver", "com.ibm.db2.jdbc.net.DB2Driver", 
				"com.jdbc.odbc.JdbcOdbcDriver"};
		JComboBox comboBox_1 = new JComboBox(drivers);
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				driver = drivers[0];
			}
		});
		comboBox_1.setForeground(Color.BLACK);
		comboBox_1.setFont(new Font("Times New Roman", Font.PLAIN, 17));
		comboBox_1.setBackground(Color.WHITE);
		comboBox_1.setBounds(145, 41, 222, 27);
		frmSqlClientApp.getContentPane().add(comboBox_1);
	}
	
	@SuppressWarnings("deprecation")
	public boolean connect(String password, String user, String url) {
		//String pass = new String(password);
		
		try {
			connection = DriverManager.getConnection(url, user, password);
		} catch (CommunicationsException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			JOptionPane.showMessageDialog(null, "Database not found", "Error", JOptionPane.INFORMATION_MESSAGE);
			return false;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.fillInStackTrace();
			JOptionPane.showMessageDialog(null, "Wrong username or password", "Error", JOptionPane.INFORMATION_MESSAGE);
			return false;
		} 
		return true;
	}
}
