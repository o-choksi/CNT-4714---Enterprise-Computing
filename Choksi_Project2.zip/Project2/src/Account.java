/*	Name: Om Choksi
 	Course: CNT 4714 Spring 2021
 	Assignment title: Project 2 � Synchronized, Cooperating Threads Under Locking
 	Due Date: February 17, 2021
 */
import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class Account {
	//Global variables
	public int balance = 0;
	public Lock lock1 = new ReentrantLock();
	public Condition funds = lock1.newCondition();
	
	//Random deposit and withdrawal amounts
	public int randomAmount(boolean b) {
		Random r = new Random();
		
		//Deposit Amount
		if (b) {
			return (r.nextInt(250) + 1);
		}
		//Withdraw Amount
		else {
			return (r.nextInt(50) + 1);
		}
	}
	
	//Deposit function
	public void deposit() {
		//Getting deposit amount and implementing lock
		int deposit = randomAmount(true);
		lock1.lock();
		
		try {
			balance += deposit;
			System.out.println("Thread " + Thread.currentThread().getName() + " deposits $" + deposit + "\t\t\t\t\t\t\t\t(+) Balance is $"
					+ balance);
			funds.signal();
		}
		catch (Exception e) {
			e.printStackTrace(System.out);
		}
		finally {
			lock1.unlock();
		}
	}

	//Withdraw function
	public void withdraw() {
		//Getting withdrawal amount and implementing lock
		int withdraw = randomAmount(false);
		lock1.lock();
		
		try {
			if (balance < withdraw) {
				System.out.println("\t\t\t\t\tThread " + Thread.currentThread().getName() + " withdraws $" + withdraw + "\t\t\t(***)"
						+ " Withdrawal - Blocked - Insufficient Funds!");
				funds.await();
				return;
			}
			else {
				balance -= withdraw;
				System.out.println("\t\t\t\t\tThread " + Thread.currentThread().getName() + " withdraws $" + withdraw + "\t\t\t(-) Balance is $"
						+ balance);
			}
		}
		catch (Exception e) {
			e.printStackTrace(System.out);
		}
		finally {
			lock1.unlock();
		}
	}
}
