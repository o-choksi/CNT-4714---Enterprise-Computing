/*	Name: Om Choksi
 	Course: CNT 4714 Spring 2021
 	Assignment title: Project 2 � Synchronized, Cooperating Threads Under Locking
 	Due Date: February 17, 2021
 */
public class Main {

	public static void main(String[] args) {
		//Setting up output
		System.out.printf("Deposit Threads\t\t\t\tWithdrawal Threads\t\t\tBalance\t\t\t\n");
		System.out.printf("---------------\t\t\t\t-------------------\t\t\t------------------\t\t\t\n");
		
		//Account object
		Account a = new Account();
		
		//5 Deposit Threads and setting names;
		Deposit d1 = new Deposit(a);
		d1.setName("D1");
		Deposit d2 = new Deposit(a);
		d2.setName("D2");
		Deposit d3 = new Deposit(a);
		d3.setName("D3");
		Deposit d4 = new Deposit(a);
		d4.setName("D4");
		Deposit d5 = new Deposit(a);
		d5.setName("D5");
		
		//9 Withdraw Threads and setting names;
		Withdraw w1 = new Withdraw(a);
		w1.setName("W1");
		Withdraw w2 = new Withdraw(a);
		w2.setName("W2");
		Withdraw w3 = new Withdraw(a);
		w3.setName("W3");
		Withdraw w4 = new Withdraw(a);
		w4.setName("W4");
		Withdraw w5 = new Withdraw(a);
		w5.setName("W5");
		Withdraw w6 = new Withdraw(a);
		w6.setName("W6");
		Withdraw w7 = new Withdraw(a);
		w7.setName("W7");
		Withdraw w8 = new Withdraw(a);
		w8.setName("W8");
		Withdraw w9 = new Withdraw(a);
		w9.setName("W9");
		
		//Starting Threads
		d1.start();
		d2.start();
		w1.start();
		w2.start();
		d3.start();
		d4.start();
		w3.start();
		w4.start();
		d5.start();
		w5.start();
		w6.start();
		w7.start();
		w8.start();
		w9.start();
	}

}
