/*	Name: Om Choksi
 	Course: CNT 4714 Spring 2021
 	Assignment title: Project 2 � Synchronized, Cooperating Threads Under Locking
 	Due Date: February 17, 2021
 */
import java.util.Random;

public class Withdraw extends Thread{
	//Global variables
	private Account a1;
	
	public Withdraw(Account a) {
		//Assigning Account object into Thread
		a1 = a;
	}
	
	//Random sleep time
	public int randomSleep() {
		Random r = new Random();
		return (r.nextInt(1000) + 1);
	}

	@Override
	//Run method that calls withdraw from Account object
	public void run() {
		try {
			while(true) {
				a1.withdraw();
				Thread.sleep(randomSleep());
			}
		}
		catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}
}
