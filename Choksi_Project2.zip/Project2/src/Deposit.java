/*	Name: Om Choksi
 	Course: CNT 4714 Spring 2021
 	Assignment title: Project 2 � Synchronized, Cooperating Threads Under Locking
 	Due Date: February 17, 2021
 */
import java.util.Random;

public class Deposit extends Thread{
	//Global variables
	private Account a1;
	
	public Deposit(Account a) {
		//Assigning Account object into Thread
		a1 = a;
	}
	
	//Random sleep time
	public int randomSleep() {
		Random r = new Random();
		return (r.nextInt(1501) + 1000);
	}
	
	@Override
	//Run method that calls deposit from Account object
	public void run() {
		try {
			while(true) {
				a1.deposit();
				Thread.sleep(randomSleep());
			}
		}
		catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}
}
